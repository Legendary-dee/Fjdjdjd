<script lang="ts">
import Skeleton from './Skeleton.svelte'

export let size = 20
</script>

<Skeleton colorScheme="darkGray" width={size} height={size} />
