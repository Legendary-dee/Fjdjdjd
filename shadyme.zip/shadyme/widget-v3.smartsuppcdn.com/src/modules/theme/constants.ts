export const colors = {
	white: '#ffffff',
	slate100: '#f1f5f9',
	slate200: '#e2e8f0',
	slate300: '#cbd5e1',
	slate900: '#0f172a',
	blue700: '#1d4ed8',
	smartsuppBlue: '#1233df',
}
