export const SMARTSUPP_CHAT_ID = 'data-smartsupp-id'
