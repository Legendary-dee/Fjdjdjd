<script lang="ts">
import WidgetButtonBubble from './WidgetButtonBubble.svelte'
</script>

<div class="p-1">
	<div class="flex-center w-12 h-12 bg-white bg-opacity-10 rounded-full">
		<WidgetButtonBubble />
	</div>
</div>
