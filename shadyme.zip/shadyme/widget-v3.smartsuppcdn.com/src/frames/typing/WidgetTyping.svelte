<script lang="ts">
import TypingIndicator from '@/components/TypingIndicator.svelte'
</script>

<div class="flex-center h-full bg-white rounded-lg">
	<TypingIndicator iterations={2} />
</div>
